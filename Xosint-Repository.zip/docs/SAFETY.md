# Safety and limitations

Xosint requests public profile URLs using ordinary HTTP requests. It does not log
in, bypass access controls, access private accounts, retrieve passwords, or evade
site protections.

Automated URL checks can be inaccurate:
- HTTP 200 may be a login page, challenge, or generic landing page.
- HTTP 404 may be temporary or site-specific.
- Rate limits, bot protection, network failures, and URL changes affect results.

Use only for lawful, proportionate research. Respect site terms and rate limits.
Do not use it to harass, stalk, dox, or target people.
