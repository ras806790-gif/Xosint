<div align="center">

<img src="assets/xosint-logo.png" alt="Xosint logo" width="720">

# Xosint
### Lightweight public username checker for Android & Termux

[![Platform](https://img.shields.io/badge/platform-Termux%20%7C%20Android-3DDC84?style=for-the-badge)](#persyaratan)
[![Python](https://img.shields.io/badge/Python-3.9%2B-3776AB?style=for-the-badge&logo=python&logoColor=white)](https://python.org)
[![License](https://img.shields.io/badge/license-MIT-blue?style=for-the-badge)](LICENSE)

**Xosint** adalah tool OSINT ringan untuk memeriksa apakah URL profil publik merespons saat dicari menggunakan username. Dirancang agar bisa dijalankan langsung di Android melalui Termux, tanpa perlu Kali Linux.

</div>

> **Penting:** Xosint hanya memberi indikasi teknis berdasarkan respons situs. Hasilnya bukan bukti bahwa suatu akun benar-benar ada, aktif, atau dimiliki orang tertentu.

## Tentang Xosint

Xosint membantu pencarian awal terhadap profil publik yang mungkin memakai username tertentu di sejumlah platform. Tool ini menyusun URL profil yang telah ditentukan, mengirim permintaan HTTP biasa, lalu menampilkan respons yang diterima.

### Kegunaan
- Memeriksa URL profil publik berdasarkan username.
- Membantu riset OSINT awal terhadap informasi yang tersedia secara publik.
- Membandingkan kemungkinan penggunaan username yang sama di beberapa platform.
- Menyimpan hasil pemeriksaan ke laporan `.txt`.
- Berlatih memahami dasar Python, HTTP, dan OSINT secara bertanggung jawab.

### Batasan
Xosint bukan alat untuk membobol akun, mencuri kata sandi, membuka akun privat, melewati sistem keamanan, melacak lokasi real-time, atau memastikan identitas asli pemilik akun.

## Fitur
- 📱 Dirancang untuk Android dan Termux.
- 🔎 Memeriksa daftar URL profil publik yang telah dikonfigurasi.
- ⚡ Memeriksa beberapa situs secara bersamaan dengan batas koneksi.
- 📝 Menyimpan laporan TXT dengan tanggal dan waktu.
- 🐍 Menggunakan standard library Python; tidak perlu paket Python tambahan.
- 📋 Status hasil disertai catatan keterbatasan.

## Persyaratan
- Android dengan [Termux](https://termux.dev/) terpasang.
- Python 3.9 atau lebih baru.
- Koneksi internet.

Kali Linux tidak diperlukan.

## Instalasi dan penggunaan di Termux

### 1. Perbarui paket Termux
```bash
pkg update && pkg upgrade -y
```

### 2. Pasang Git dan Python
```bash
pkg install git python -y
```

### 3. Unduh repository
Ganti `USERNAME_GITHUB` dengan username GitHub pemilik repository ini.
```bash
git clone https://github.com/USERNAME_GITHUB/Xosint.git
cd Xosint
```

### 4. Jalankan installer
```bash
chmod +x install.sh
bash install.sh
```

### 5. Jalankan Xosint
Mode interaktif — program akan meminta username:
```bash
python xosint.py
```

Atau masukkan username langsung:
```bash
python xosint.py contoh_username
```

Masukkan username saja, bukan URL lengkap. Tanda `@` di depan username boleh disertakan atau dihilangkan.

### 6. Baca hasil
Laporan disimpan di folder kerja saat ini, contohnya:
```text
xosint_contoh_username_20261013_120000.txt
```

Lihat laporan:
```bash
ls xosint_*.txt
cat nama_file_laporan.txt
```
Ganti `nama_file_laporan.txt` dengan nama file laporan yang sebenarnya.

## Arti status hasil

| Status | Arti |
|---|---|
| `POTENTIAL` | URL merespons dengan HTTP 200. Periksa manual; halaman login atau halaman umum juga bisa merespons 200. |
| `NOT DETECTED` | Situs mengembalikan HTTP 404. Ini bukan bukti pasti bahwa akun tidak ada. |
| `UNKNOWN` | Respons tidak dapat ditafsirkan secara andal, misalnya situs membatasi permintaan. |
| `ERROR` | Permintaan gagal, misalnya karena internet, DNS, TLS, atau timeout. |

Situs dapat mengubah format URL, menerapkan pembatasan otomatis, atau menampilkan halaman yang tidak bisa dinilai hanya dari kode HTTP.

## Disclaimer dan penggunaan yang bertanggung jawab

Dengan menggunakan Xosint, pengguna bertanggung jawab atas cara tool ini dijalankan dan bagaimana hasilnya digunakan.

1. **Tujuan terbatas:** Xosint dibuat untuk pembelajaran, pengujian yang sah, dan riset terhadap informasi publik.
2. **Patuhi hukum:** Pengguna wajib mematuhi hukum yang berlaku di wilayahnya serta ketentuan layanan setiap platform.
3. **Hormati privasi:** Jangan gunakan hasil untuk menguntit, melecehkan, mengancam, melakukan doxing, diskriminasi, atau menargetkan seseorang.
4. **Tidak ada jaminan akurasi:** Hasil otomatis bisa salah, tidak lengkap, kedaluwarsa, atau terpengaruh pembatasan situs. Verifikasi manual sebelum mengambil kesimpulan.
5. **Tidak ada afiliasi resmi:** Xosint adalah proyek independen dan tidak berafiliasi dengan atau didukung secara resmi oleh platform yang diperiksa maupun Sherlock Project.
6. **Tanpa jaminan:** Perangkat lunak disediakan “apa adanya”, tanpa jaminan apa pun, sejauh diizinkan hukum.
7. **Tanggung jawab pengguna:** Pengembang tidak mendorong penggunaan ilegal atau merugikan. Pengguna bertanggung jawab atas penggunaan dan tindakan berdasarkan hasil tool ini.

> **Catatan hukum:** Disclaimer ini menjelaskan tujuan dan batasan proyek, tetapi tidak memberikan kekebalan hukum dan tidak menjamin pengguna atau pengembang bebas dari tanggung jawab. Hukum yang berlaku dan keadaan setiap kasus tetap menentukan.

## Developer
- **TikTok:** [@rasfunix](https://www.tiktok.com/@rasfunix)
- **Instagram:** [@rasyahgh](https://www.instagram.com/rasyahgh)

## Credits
Xosint terinspirasi oleh komunitas open-source OSINT dan gagasan pencarian profil publik berbasis username.

Terima kasih kepada:
- [Sherlock Project](https://github.com/sherlock-project/sherlock) atas inspirasi konsep pencarian username lintas situs.
- Semua orang yang melaporkan bug, memperbaiki dokumentasi, dan berkontribusi secara bertanggung jawab.

Xosint adalah proyek independen dan **tidak berafiliasi dengan atau didukung oleh Sherlock Project**.

## Kontribusi
Bug report dan pull request dipersilakan. Jangan sertakan data pribadi atau sensitif dalam laporan.

## Lisensi
Xosint dirilis di bawah lisensi MIT. Lihat file [LICENSE](LICENSE).
